"""Residential Floorplans and City Scapes dataset for Urban planning"""


import json
import datasets


logger = datasets.logging.get_logger(__name__)


_CITATION = """\
@article{2016arXiv160605250R,
       author = {{Rajpurkar}, Pranav and {Zhang}, Jian and {Lopyrev},
                 Konstantin and {Liang}, Percy},
        title = "{SQuAD: 100,000+ Questions for Machine Comprehension of Text}",
      journal = {arXiv e-prints},
         year = 2016,
          eid = {arXiv:1606.05250},
        pages = {arXiv:1606.05250},
archivePrefix = {arXiv},
       eprint = {1606.05250},
}
"""

_DESCRIPTION = """\
Text-to-image model to build an AI architect
"""

_URL = "https://huggingface.co/datasets/wheres-my-python/image-trial/resolve/main/images.tar.gz"

# descriptions = [] #optional text data

class ImagesTrial(datasets.GeneratorBasedBuilder):
    """SQUAD: The Stanford Question Answering Dataset. Version 1.1."""

    def _info(self):
        return datasets.DatasetInfo(
            description=_DESCRIPTION,
            features=datasets.Features(
                # Option to use any Apache arrow feature other than "string"
                {
                    "text": datasets.Value("string"),
                    "image": datasets.Image(),
                    # "prompt": datasets.Value("string"),   (optional)
                }
            ),
            # No default supervised_keys (as we have to pass both question
            # and context as input).
            supervised_keys=None,
            homepage="https://huggingface.co/datasets/wheres-my-python/floorplans-cityscapes",
            citation=_CITATION,
            
        )

    def _split_generators(self, dl_manager):
        #download manager - hf utility
        path = dl_manager.download_and_extract(_URL)
        image_iters = dl_manager.iter_archive(path)

        return [
            datasets.SplitGenerator(
                name=datasets.Split.TRAIN
                , gen_kwargs={
                    "images": image_iters
                }
            ),
        ]

    def _generate_examples(self, images):
        """This function returns the examples in the raw (text) form."""
        idx = 0
        #iteratre through images
        for filepath, image in images:
            yield idx, {
                "image": {"filepath":filepath, "image":image.read()},
                #Option to map text

                # "text": descriptions[idx],
            }
            idx +=1