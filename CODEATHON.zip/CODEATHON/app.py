from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Dummy user data (replace with database)
users = {
    "admin": "adminpassword"
}

@app.route("/")
def index():
    return render_template("C:/Users/Ramiya/Desktop/Codeathon/Codeathon/login.html")

@app.route("/login", methods=["POST"])
def login():
    username = request.form.get("username")
    password = request.form.get("password")
    if username in users and users[username] == password:
        return "Login successful!"
    else:
        return "Invalid username or password."

@app.route("/register")
def register():
    return render_template("C:/Users/Ramiya/Desktop/Codeathon/Codeathon/templates/register.html")

@app.route("/register", methods=["POST"])
def register_user():
    username = request.form.get("username")
    password = request.form.get("password")
    users[username] = password
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)

    


