from flask import Flask, render_template, request 

app = Flask(__name__)
app.config['TEMPLATES_AUTO_RELOAD'] = True

@app.route('/')
def index():
    return render_template('D:/College stuff/CODEATHON/Codeathon/Codeathon/templates/login.html')

# @app.route('/process', methods=['POST'])
# def process():
#     input_text = request.form['input_text']
#     formatted_text = input_text.upper()  # Example: Convert input text to uppercase
#     return render_template('result.html', input_text=input_text, formatted_text=formatted_text)

if __name__ == '__main__':
    app.run(debug=True)
